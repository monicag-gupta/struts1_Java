package common.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.*;

import common.form.*;

public class LoginAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		LoginForm loginForm = (LoginForm) form;
		loginForm.setLogins(LoginFormDAO.getList());
		List<LoginForm> listLoginForm=LoginFormDAO.getList();
		request.setAttribute("listLoginForm", listLoginForm);
		System.out.println("From Action class: \n"+listLoginForm);
		
		if (loginForm.getUserName() == null || loginForm.getPassword() == null
				|| !LoginFormDAO.check(loginForm.getUserName(),loginForm.getPassword()))
				{
			return mapping.findForward("failure");
		} else
			return mapping.findForward("success");
	}
}
