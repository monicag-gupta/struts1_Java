package common.form;
import java.sql.*;
import java.util.*;

public class LoginFormDAO
{
		public static void add(LoginForm l){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "monica", "gupta");
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate("insert into LoginForm values('"+l.getUserName()+"','"+l.getPassword()+ "')");
			System.out.println(result + " records affected");
			// add ojdbc6.jar in your project library
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	public static Boolean check(String u, String p){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "monica", "gupta");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from LoginForm"); // emptbl
			while (rs.next()){
				if(u.equalsIgnoreCase(rs.getString(1)) && p.equalsIgnoreCase(rs.getString(2))){
					return true;
				}
			}
			// add ojdbc6.jar in your project library
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return false;
	}
	public static List<LoginForm> getList(){
		List<LoginForm> l=new ArrayList<LoginForm>();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "monica", "gupta");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from LoginForm"); // emptbl
			while (rs.next()){
				System.out.println(rs.getString(1) + "  " + rs.getString(2));
				l.add(new LoginForm(rs.getString(1),rs.getString(2)));
			}
			// add ojdbc6.jar in your project library
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return l;
	}
	public static void remove(String u, String p){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "monica", "gupta");
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate("delete from LoginForm where userName = '"+u+"' and password = '"+p+ "';");
			System.out.println(result + " records affected");
			// add ojdbc6.jar in your project library
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	public static void update(String u, String p){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "monica", "gupta");
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate("update LoginForm set password = '"+p+ "' where userName = '"+u+"';");
			System.out.println(result + " records affected");
			// add ojdbc6.jar in your project library
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
}
