package common.form;
import java.util.*;

public class RepoLogin {
	static ArrayList<LoginForm> logins =  new ArrayList<LoginForm>();
	
	static{			
		logins.add(new LoginForm("A11", "B11"));
		logins.add(new LoginForm("A21", "B21"));
		logins.add(new LoginForm("A31", "B31"));
		logins.add(new LoginForm("A41", "B41"));
	}
//	static ArrayList<LoginForm> logins=new ArrayList<LoginForm>(initlogins);
	
	public RepoLogin(){
		logins.add(new LoginForm("A1", "B1"));
		logins.add(new LoginForm("A2", "B2"));
		logins.add(new LoginForm("A3", "B3"));
		logins.add(new LoginForm("A4", "B4"));
	}
	public static void add(LoginForm l){
		System.out.println("Before Adding:\n"+ logins);
		logins.add(l);
		System.out.println("After Adding:\n"+ logins);
	}
	public static Boolean check(String u, String p){
		System.out.println("The Listis:\n"+logins);
		for(LoginForm l : logins){
			if(l.getUserName().equalsIgnoreCase(u) && l.getPassword().equalsIgnoreCase(p))
				return true;
		}
		
		return false;
	}
	public static List<LoginForm> getList(){
		return (List<LoginForm>)logins;
	}
	public static void remove(String u, String p){
		System.out.println("Before Removal:\n"+logins);
		int i = -1, j=0;
		for(LoginForm l : logins){
			i++;
			if(l.getUserName().equalsIgnoreCase(u) && l.getPassword().equalsIgnoreCase(p)){
				j=1;
				break;
			}
		}
		if(j==1){
			logins.remove(i);
		}
		
		System.out.println("After Removal\n"+logins);
	}
	
}
