package common.form;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class LoginForm extends ActionForm {

	private static final long serialVersionUID = 1L;
	private String userName = null;
	private String password = null;
	List<LoginForm> logins=null;

	public List<LoginForm> getLogins() {
		return logins;
	}

	public void setLogins(List<LoginForm> logins) {
		this.logins = logins;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		this.password = null;
	}
	public LoginForm(){}
	public LoginForm(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}

	@Override
	public String toString() {
		return "LoginForm [" + userName + ", " + password + "]";
	}
	
}
